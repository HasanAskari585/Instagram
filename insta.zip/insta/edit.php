<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" ></a>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Instagram</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Instagram</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
    </div>
  </div>
</nav>
    <div class="container">

    <center>
    <h1>Edit Postingan</h1>
    </center>

    <form action="proses_edit.php" method="post" enctype="multipart/form-data" class="form-control">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>" class="form-control">
        
        <label for="">Gambar</label>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" class="form-control"><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control"><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <input type="submit" value="Update" name="update" class="btn btn-primary">
    </form>
</body>
</div>
</html>

<?php } ?>