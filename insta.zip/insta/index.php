<?php
session_start();

if (!isset($_SESSION['login'])) {
  header("location:login.php?pesan=login");
}

include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);

$no = $_GET['no'];
$sql1 = "SELECT * FROM post WHERE no = '$no' ";
$query1 = mysqli_query($koneksi, $sql1);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" href="logo3.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ninja Heroes New Era</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
  integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
    crossorigin="anonymous"></script>

  <style>
    .zoom {
      transition: transform .2s;
      /* Animation */
      margin: 0 auto;
    }

    .zoom:hover {
      transform: scale(1.1);
      /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
    }

    body {
      background: #D8D9DA;
      background-image: url('images/g');
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;

    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
    <div class="container-fluid">
      <img src="logo3.png" width="65px" alt="">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03"
        aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="" aria-disabled="true" color="red">Ninja Heroes New Era</a>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        </ul>
        <a href="#" class="nav-link"><button type="submit" class="btn btn-outline-light" data-bs-toggle="modal"
            data-bs-target="#exampleModal"><i class="fa fa-plus-square"></i></button></a>
            <a href="logout.php" class="btn btn-danger"><i class="fa-solid fa-right-from-bracket"></i></a><br>
      </div>
    </div>
  </nav> <br><br><br><br>

  <div class="container">
    <center>
      <?php while ($post = mysqli_fetch_assoc($query)) { ?>
        <div class="card mt-5 justify-content-center shadow p-3 mb-3 bg-body rounded" style="width: 31rem;">
          <p class="card-text">
            <?= $post['lokasi'] ?>
          </p><br>
          <div class="zoom">
            <img class="card-img-top zoom" src="images/<?= $post['foto'] ?>" alt="Card image cap"
              style="border-radius: 15px">
          </div>
          <div class="d-flex flex-column" style="position: absolute;top:2%;left: 89%;">
            <a href="hapus.php?no=<?= $post['no'] ?>" class="btn"><i class="fa fa-trash fa-spin-pulse fa-2xl"
                style="font-size:24px"></i></a>
          </div><br><br>
          <div class="card-body">
            <p>
              <?= $post['caption'] ?>
            </p>
          </div>
          <button type="button" class="btn btn-success" data-bs-toggle="modal"
            data-bs-target="#editModal<?= $post['no'] ?>"><i
              class="fa-regular fa-pen-to-square fa-flip fa-2xl"></i></button>
        </div>

        <!-- Modal Edit-->
        <div class="modal fade" id="editModal<?= $post['no'] ?>" data-bs-backdrop="static" data-bs-keyboard="false"
          tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Form Edit Postingan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="container" align="left">
                <form action="proses_edit.php" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="no" value="<?= $post['no'] ?>">
                  <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>" class="form-control">

                  <label for="">foto</label>
                  <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" class="form-control"><br>
                  <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
                  <label for="">Caption</label>
                  <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control"><br>
                  <label for="">Lokasi</label>
                  <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control"><br>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="update">Update</button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>
  </div>


  <!-- Modal Tambah-->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

            <label for="" class="form-label">foto</label><br>
            <input class="form-control" type="file" name="foto" id="" required><br><br>

            <label for="" class="form-label">Caption</label><br>
            <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

            <label for="" class="form-label">Nama</label><br>
            <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <input type="submit" name="simpan" class="btn btn-primary"></button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>


</body>

</html>