<?php
include "koneksi.php";
require "functions.php";

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $foto_lama = $_POST['foto_lama'];
    $foto_baru = $_FILES['foto']['name'];

    // jika fotonya sama, pakai foto yang lama
    if( $_FILES['foto']['error'] === 4 ) {
		$foto = $foto_lama;
	} else {
        $sql = "SELECT * FROM post WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    
        // menghapus foto lama karena nanti akan diganti yang baru
        while($post = mysqli_fetch_assoc($query)) {
            $foto = $post['foto'];
            unlink('images/' . $foto);
        }

        // lakukan proses upload foto baru
		$foto = upload();
	}
    
    $sql2 = "UPDATE post SET foto = '$foto', caption = '$caption', lokasi = '$lokasi' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        header("location:index.php?edit=sukses");
    } else {
        header("location:index.php?edit=gagal");
    }
    
}